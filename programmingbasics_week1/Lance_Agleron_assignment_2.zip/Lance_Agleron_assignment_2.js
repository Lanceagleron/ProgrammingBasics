var RequiredHeight = '42 inches'; 
//Rider must be at least 42 inches tall to ride
var RequiredAge = 10;
//Rider must be over at the age of 10 to ride
